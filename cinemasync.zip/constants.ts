import { Movie } from "./types";

export const DEMO_MOVIES: Movie[] = [
    { id: '1', title: 'The Batman', year: '2022', genre: 'Action', rating: '4.8', emoji: '🦇', color: 'from-gray-900 to-gray-800' },
    { id: '2', title: 'Dune', year: '2021', genre: 'Sci-Fi', rating: '4.7', emoji: '🏜️', color: 'from-orange-800 to-amber-700' },
    { id: '3', title: 'Spider-Verse', year: '2018', genre: 'Animation', rating: '4.9', emoji: '🕷️', color: 'from-red-600 to-blue-600' },
    { id: '4', title: 'Parasite', year: '2019', genre: 'Thriller', rating: '4.8', emoji: '🏠', color: 'from-green-900 to-gray-900' },
    { id: '5', title: 'La La Land', year: '2016', genre: 'Musical', rating: '4.6', emoji: '🎭', color: 'from-yellow-400 to-purple-600' },
    { id: '6', title: 'Interstellar', year: '2014', genre: 'Sci-Fi', rating: '4.9', emoji: '🌌', color: 'from-blue-900 to-black' },
];

export const MOCK_ROOMS = [
    { id: 'DEMO-ROOM', name: 'Friday Night Movies', count: '3/8', type: 'Public', watching: 'The Avengers' },
    { id: 'ROMANCE', name: 'Date Night', count: '2/2', type: 'Private', watching: 'Ready to start' },
    { id: 'HORROR', name: 'Horror Marathon', count: '5/16', type: 'Friends', watching: 'The Conjuring' },
];
