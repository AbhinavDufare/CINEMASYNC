export interface User {
    id: string;
    name: string;
    email: string;
    avatar?: string;
}

export interface Message {
    id: string;
    sender: string;
    text: string;
    timestamp: string;
    isSystem: boolean;
}

export interface Room {
    id: string;
    name: string;
    maxParticipants: number;
    privacy: 'private' | 'friends' | 'public';
    participants: User[];
    currentMovie?: string;
    isPlaying: boolean;
}

export interface Movie {
    id: string;
    title: string;
    year: string;
    genre: string;
    rating: string;
    emoji: string;
    color: string;
}

export type ViewState = 'home' | 'room' | 'discover' | 'schedule' | 'platforms';

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
    id: string;
    message: string;
    type: ToastType;
}
