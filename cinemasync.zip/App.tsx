import React, { useState, useEffect } from 'react';
import StarBackground from './components/StarBackground';
import Intro from './components/Intro';
import Navigation from './components/Navigation';
import ToastContainer from './components/ToastContainer';
import RoomInterface from './components/RoomInterface';
import { User, Room, ViewState, Toast, Message } from './types';
import { Play, Star, Plus, User as UserIcon, LogOut, ChevronRight, Lock, Unlock, Globe, Film, Search, Calendar } from 'lucide-react';
import { DEMO_MOVIES, MOCK_ROOMS } from './constants';

const App: React.FC = () => {
    const [loading, setLoading] = useState(true);
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [currentView, setCurrentView] = useState<ViewState>('home');
    const [toasts, setToasts] = useState<Toast[]>([]);
    const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
    const [showAuthModal, setShowAuthModal] = useState(false);
    const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
    const [messages, setMessages] = useState<Message[]>([]);
    const [authForm, setAuthForm] = useState({ email: '', password: '', name: '' });
    const [showUserMenu, setShowUserMenu] = useState(false);

    // Initial system message when entering a room
    useEffect(() => {
        if (currentRoom) {
            setMessages([
                { 
                    id: 'sys-1', 
                    sender: 'System', 
                    text: `Welcome to ${currentRoom.name}! 🎬`, 
                    timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                    isSystem: true 
                }
            ]);
        }
    }, [currentRoom]);

    const addToast = (message: string, type: Toast['type'] = 'info') => {
        const id = Math.random().toString(36).substr(2, 9);
        setToasts(prev => [...prev, { id, message, type }]);
        setTimeout(() => removeToast(id), 4000);
    };

    const removeToast = (id: string) => {
        setToasts(prev => prev.filter(t => t.id !== id));
    };

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        // Simulate API call
        setTimeout(() => {
            if ((authForm.email.includes('@') && authForm.password.length >= 6) || (authForm.email === 'demo' && authForm.password === 'demo')) {
                setCurrentUser({
                    id: 'u1',
                    name: authForm.name || 'Demo User',
                    email: authForm.email,
                    avatar: 'DU'
                });
                setShowAuthModal(false);
                addToast('Welcome back! Ready for a movie? 🍿', 'success');
            } else {
                addToast('Invalid credentials. Try demo/demo', 'error');
            }
        }, 1000);
    };

    const handleSendMessage = (text: string) => {
        if (!currentUser) return;
        const newMsg: Message = {
            id: Date.now().toString(),
            sender: currentUser.name,
            text,
            timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
            isSystem: false
        };
        setMessages(prev => [...prev, newMsg]);

        // Auto-reply simulation
        setTimeout(() => {
            const replies = ["That scene was intense! 😱", "LOL 😂", "Wait, what just happened?", "I love this soundtrack 🎵"];
            const reply: Message = {
                id: (Date.now() + 1).toString(),
                sender: 'Sarah',
                text: replies[Math.floor(Math.random() * replies.length)],
                timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
                isSystem: false
            };
            setMessages(prev => [...prev, reply]);
        }, 2000);
    };

    const joinRoom = (roomId: string) => {
        if (!currentUser) {
            addToast('Please sign in to join a room', 'warning');
            setShowAuthModal(true);
            return;
        }
        
        const room = MOCK_ROOMS.find(r => r.id === roomId);
        if (room) {
             const newRoom: Room = {
                id: room.id,
                name: room.name,
                maxParticipants: 10,
                privacy: 'public',
                participants: [currentUser],
                currentMovie: room.watching,
                isPlaying: false
            };
            setCurrentRoom(newRoom);
            setCurrentView('room');
            addToast(`Joined ${room.name} successfully`, 'success');
        }
    };

    if (loading) {
        return <Intro onComplete={() => setLoading(false)} />;
    }

    return (
        <div className="min-h-screen text-brand-text font-sans selection:bg-brand-primary/30 pb-20 md:pb-0">
            <StarBackground />
            <ToastContainer toasts={toasts} onRemove={removeToast} />

            {/* Header */}
            <header className="fixed top-0 left-0 right-0 z-40 bg-brand-darker/80 backdrop-blur-xl border-b border-brand-primary/10">
                <div className="container mx-auto px-4 h-16 flex items-center justify-between">
                    <div 
                        className="text-2xl font-bold bg-gradient-to-r from-brand-primary to-brand-secondary bg-clip-text text-transparent cursor-pointer"
                        onClick={() => setCurrentView('home')}
                    >
                        CinemaSync
                    </div>

                    <div className="flex items-center gap-4">
                        {currentUser ? (
                            <div className="relative">
                                <button 
                                    onClick={() => setShowUserMenu(!showUserMenu)}
                                    className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-primary to-brand-secondary p-[2px] shadow-lg shadow-brand-primary/20"
                                >
                                    <div className="w-full h-full rounded-full bg-brand-darker flex items-center justify-center font-bold text-brand-primary">
                                        {currentUser.avatar}
                                    </div>
                                </button>
                                
                                {showUserMenu && (
                                    <div className="absolute right-0 top-12 w-48 glass-panel rounded-xl shadow-2xl py-2 animate-[slideIn_0.2s_ease-out]">
                                        <div className="px-4 py-2 border-b border-brand-primary/10 mb-2">
                                            <p className="font-bold text-white">{currentUser.name}</p>
                                            <p className="text-xs text-brand-muted truncate">{currentUser.email}</p>
                                        </div>
                                        <button className="w-full text-left px-4 py-2 text-sm hover:bg-white/5 transition-colors flex items-center gap-2">
                                            <UserIcon size={14} /> Profile
                                        </button>
                                        <button 
                                            onClick={() => {
                                                setCurrentUser(null);
                                                setCurrentRoom(null);
                                                setShowUserMenu(false);
                                                addToast('Signed out successfully', 'info');
                                            }}
                                            className="w-full text-left px-4 py-2 text-sm hover:bg-red-500/10 text-red-300 transition-colors flex items-center gap-2"
                                        >
                                            <LogOut size={14} /> Sign Out
                                        </button>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="flex gap-2">
                                <button 
                                    onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
                                    className="text-sm font-medium px-4 py-2 text-brand-primary hover:text-brand-secondary transition-colors"
                                >
                                    Sign In
                                </button>
                                <button 
                                    onClick={() => { setAuthMode('register'); setShowAuthModal(true); }}
                                    className="text-sm font-medium px-4 py-2 bg-brand-primary text-brand-darker rounded-full hover:bg-brand-secondary transition-colors shadow-lg shadow-brand-primary/20"
                                >
                                    Join
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="container mx-auto px-4 pt-24 min-h-[calc(100vh-80px)]">
                
                <Navigation currentView={currentView} onChange={setCurrentView} />

                {/* Home View */}
                {currentView === 'home' && (
                    <div className="animate-[fadeIn_0.5s_ease-out]">
                        <div className="text-center mb-12">
                            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">
                                Your Perfect <span className="text-brand-primary">Movie Night</span>
                            </h1>
                            <p className="text-brand-muted max-w-2xl mx-auto text-lg">
                                Connect with friends and loved ones through the magic of cinema. 
                                Synchronized viewing, real-time chat, and zero latency.
                            </p>
                        </div>

                        {!currentUser && (
                            <div className="glass-panel p-8 rounded-3xl text-center mb-12 max-w-lg mx-auto transform hover:scale-105 transition-transform duration-300">
                                <h3 className="text-2xl font-bold text-white mb-4">Start Watching Now</h3>
                                <p className="text-brand-muted mb-6">Create a free account to host movie nights.</p>
                                <button 
                                    onClick={() => { setAuthMode('register'); setShowAuthModal(true); }}
                                    className="w-full py-4 bg-gradient-to-r from-brand-primary to-brand-secondary text-brand-darker font-bold rounded-xl shadow-lg hover:shadow-brand-primary/40 transition-all text-lg"
                                >
                                    Get Started
                                </button>
                                <button 
                                    onClick={() => {
                                        setAuthForm({ email: 'demo', password: 'demo', name: 'Guest' });
                                        handleLogin({ preventDefault: () => {} } as React.FormEvent);
                                    }}
                                    className="mt-4 text-sm text-brand-muted hover:text-white underline decoration-dotted"
                                >
                                    Try Demo Account
                                </button>
                            </div>
                        )}

                        {/* Room List */}
                        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <Globe className="text-brand-primary" /> Live Public Rooms
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
                            {MOCK_ROOMS.map((room) => (
                                <div 
                                    key={room.id}
                                    onClick={() => joinRoom(room.id)}
                                    className="glass-panel p-6 rounded-2xl cursor-pointer hover:border-brand-primary/40 hover:-translate-y-1 transition-all group"
                                >
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h3 className="font-bold text-white text-lg group-hover:text-brand-primary transition-colors">{room.name}</h3>
                                            <span className="text-xs px-2 py-1 rounded bg-white/5 text-brand-muted mt-1 inline-block">
                                                {room.type}
                                            </span>
                                        </div>
                                        <span className="text-brand-secondary text-sm font-mono bg-brand-secondary/10 px-2 py-1 rounded">
                                            {room.count}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-brand-muted">
                                        <Play size={14} className="text-brand-primary" /> 
                                        Playing: <span className="text-white">{room.watching}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Room View */}
                {currentView === 'room' && (
                    <div className="animate-[fadeIn_0.5s_ease-out]">
                        {currentRoom ? (
                            <RoomInterface 
                                room={currentRoom}
                                currentUser={currentUser!}
                                onLeave={() => {
                                    setCurrentRoom(null);
                                    setCurrentView('home');
                                    addToast('Left room', 'info');
                                }}
                                onSendMessage={handleSendMessage}
                                messages={messages}
                            />
                        ) : (
                            <div className="text-center py-20">
                                <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                                    <Film size={40} className="text-white/20" />
                                </div>
                                <h2 className="text-2xl font-bold text-white mb-2">No Active Room</h2>
                                <p className="text-brand-muted mb-8">Join a room from the Home screen or create a new one.</p>
                                <button 
                                    onClick={() => setCurrentView('home')}
                                    className="px-8 py-3 bg-brand-primary text-brand-darker font-bold rounded-xl"
                                >
                                    Browse Rooms
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* Discover View */}
                {currentView === 'discover' && (
                    <div className="animate-[fadeIn_0.5s_ease-out]">
                        <div className="relative mb-8">
                            <input 
                                type="text" 
                                placeholder="Search movies, genres..." 
                                className="w-full bg-white/5 border border-brand-primary/20 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:border-brand-primary/50 transition-colors"
                            />
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-muted" size={20} />
                        </div>

                        <h2 className="text-xl font-bold text-white mb-6">Trending Now</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                            {DEMO_MOVIES.map((movie) => (
                                <div key={movie.id} className="group relative aspect-[2/3] rounded-xl overflow-hidden cursor-pointer">
                                    <div className={`absolute inset-0 bg-gradient-to-br ${movie.color} opacity-80 group-hover:opacity-100 transition-opacity`} />
                                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center transform transition-transform group-hover:scale-105">
                                        <span className="text-5xl mb-4 drop-shadow-lg">{movie.emoji}</span>
                                        <h3 className="font-bold text-white text-lg leading-tight mb-1">{movie.title}</h3>
                                        <p className="text-white/70 text-sm">{movie.year} • {movie.genre}</p>
                                        <div className="mt-3 flex items-center gap-1 text-brand-secondary text-sm font-bold bg-black/40 px-3 py-1 rounded-full backdrop-blur-sm">
                                            <Star size={12} fill="currentColor" /> {movie.rating}
                                        </div>
                                    </div>
                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                                        <button className="px-6 py-2 bg-brand-primary text-brand-darker font-bold rounded-full transform translate-y-4 group-hover:translate-y-0 transition-all">
                                            Watch
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Platforms Placeholder */}
                {currentView === 'platforms' && (
                    <div className="text-center py-10 animate-[fadeIn_0.5s_ease-out]">
                        <h2 className="text-3xl font-bold text-white mb-8">Connected Services</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
                            {[
                                { name: 'Netflix', connected: true, color: 'bg-red-600' },
                                { name: 'Disney+', connected: false, color: 'bg-blue-600' },
                                { name: 'Prime Video', connected: false, color: 'bg-sky-500' },
                                { name: 'Hulu', connected: true, color: 'bg-green-500' },
                            ].map((platform) => (
                                <div key={platform.name} className="glass-panel p-6 rounded-2xl flex items-center justify-between">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-12 h-12 rounded-lg ${platform.color} flex items-center justify-center text-white font-bold text-xl`}>
                                            {platform.name[0]}
                                        </div>
                                        <div className="text-left">
                                            <h3 className="font-bold text-white">{platform.name}</h3>
                                            <p className="text-xs text-brand-muted">{platform.connected ? 'Connected' : 'Not Connected'}</p>
                                        </div>
                                    </div>
                                    <button className={`px-4 py-2 rounded-lg text-sm font-medium ${platform.connected ? 'bg-white/10 text-white' : 'bg-brand-primary text-brand-darker'}`}>
                                        {platform.connected ? 'Manage' : 'Connect'}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Schedule Placeholder */}
                {currentView === 'schedule' && (
                    <div className="flex flex-col items-center justify-center py-20 text-center animate-[fadeIn_0.5s_ease-out]">
                        <div className="w-24 h-24 bg-brand-primary/10 rounded-full flex items-center justify-center mb-6">
                            <Calendar size={48} className="text-brand-primary" />
                        </div>
                        <h2 className="text-2xl font-bold text-white mb-2">Movie Night Planner</h2>
                        <p className="text-brand-muted max-w-md mb-8">Schedule upcoming watch parties and sync with your calendar so you never miss a premiere.</p>
                        <button className="px-6 py-3 border border-brand-primary/30 text-brand-primary hover:bg-brand-primary/10 rounded-xl transition-colors">
                            Coming Soon
                        </button>
                    </div>
                )}
            </main>

            {/* Auth Modal */}
            {showAuthModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowAuthModal(false)} />
                    <div className="relative bg-brand-dark border border-brand-primary/20 w-full max-w-md p-8 rounded-3xl shadow-2xl animate-[scaleIn_0.3s_ease-out]">
                        <button 
                            onClick={() => setShowAuthModal(false)}
                            className="absolute top-4 right-4 text-brand-muted hover:text-white"
                        >
                            <UserIcon size={24} className="rotate-45" /> {/* Close icon hack */}
                        </button>
                        
                        <h2 className="text-3xl font-bold text-white mb-2 text-center">
                            {authMode === 'login' ? 'Welcome Back' : 'Join CinemaSync'}
                        </h2>
                        <p className="text-brand-muted text-center mb-8">
                            {authMode === 'login' ? 'Sign in to continue watching' : 'Create your account today'}
                        </p>

                        <form onSubmit={handleLogin} className="space-y-4">
                            {authMode === 'register' && (
                                <div>
                                    <label className="block text-sm font-medium text-brand-muted mb-1">Name</label>
                                    <input 
                                        type="text"
                                        className="w-full bg-white/5 border border-brand-primary/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-primary transition-colors"
                                        placeholder="John Doe"
                                        value={authForm.name}
                                        onChange={e => setAuthForm({...authForm, name: e.target.value})}
                                    />
                                </div>
                            )}
                            <div>
                                <label className="block text-sm font-medium text-brand-muted mb-1">Email</label>
                                <input 
                                    type="email"
                                    className="w-full bg-white/5 border border-brand-primary/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-primary transition-colors"
                                    placeholder="demo@cinemasync.com"
                                    value={authForm.email}
                                    onChange={e => setAuthForm({...authForm, email: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-brand-muted mb-1">Password</label>
                                <input 
                                    type="password"
                                    className="w-full bg-white/5 border border-brand-primary/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-primary transition-colors"
                                    placeholder="••••••"
                                    value={authForm.password}
                                    onChange={e => setAuthForm({...authForm, password: e.target.value})}
                                />
                            </div>
                            
                            <button 
                                type="submit"
                                className="w-full py-3 bg-brand-primary hover:bg-brand-secondary text-brand-darker font-bold rounded-xl transition-colors mt-4"
                            >
                                {authMode === 'login' ? 'Sign In' : 'Create Account'}
                            </button>
                        </form>

                        <div className="mt-6 text-center">
                            <button 
                                onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
                                className="text-sm text-brand-muted hover:text-white transition-colors"
                            >
                                {authMode === 'login' ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Footer Credit */}
            <div className="fixed bottom-24 md:bottom-4 left-0 right-0 text-center pointer-events-none z-0 opacity-50">
                <p className="text-[10px] text-white/40 font-medium tracking-widest uppercase">
                    created by abhinav dufare
                </p>
            </div>
        </div>
    );
};

export default App;