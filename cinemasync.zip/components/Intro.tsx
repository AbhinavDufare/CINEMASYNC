import React, { useEffect, useState } from 'react';

interface IntroProps {
    onComplete: () => void;
}

const Intro: React.FC<IntroProps> = ({ onComplete }) => {
    const [progress, setProgress] = useState(0);
    const [opacity, setOpacity] = useState(1);

    useEffect(() => {
        const timer = setTimeout(() => {
            setProgress(100);
        }, 100);

        const completeTimer = setTimeout(() => {
            setOpacity(0);
            setTimeout(onComplete, 1000); // Allow fade out
        }, 4000);

        return () => {
            clearTimeout(timer);
            clearTimeout(completeTimer);
        };
    }, [onComplete]);

    const handleSkip = () => {
        setOpacity(0);
        setTimeout(onComplete, 500);
    };

    if (opacity === 0) return null;

    return (
        <div 
            className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-brand-darker transition-opacity duration-1000"
            style={{ opacity }}
        >
            {/* Floating Emojis Background */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {['🎬', '🍿', '🎭', '📽️', '🎪', '🌟'].map((emoji, i) => (
                    <div 
                        key={i}
                        className="floating-emoji text-3xl opacity-10"
                        style={{
                            left: `${Math.random() * 100}%`,
                            animationDelay: `-${i * 2}s`
                        }}
                    >
                        {emoji}
                    </div>
                ))}
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-center animate-float relative z-10">
                <span className="bg-gradient-to-r from-brand-primary via-brand-secondary to-brand-primary bg-[length:400%_400%] bg-clip-text text-transparent animate-gradient-shift filter drop-shadow-[0_0_40px_rgba(255,138,101,0.6)]">
                    CinemaSync
                </span>
            </h1>

            <p className="text-xl text-brand-muted mb-12 font-light tracking-widest uppercase animate-pulse-slow">
                Watch Together, Apart
            </p>

            <div className="w-64 h-1 bg-brand-primary/20 rounded-full overflow-hidden mb-4">
                <div 
                    className="h-full bg-gradient-to-r from-brand-primary to-brand-secondary transition-all duration-[3000ms] ease-out shadow-[0_0_20px_rgba(255,138,101,0.5)]"
                    style={{ width: `${progress}%` }}
                />
            </div>

            <p className="text-sm text-brand-muted tracking-[0.2em] uppercase animate-pulse">
                Creating Magic...
            </p>

            <button 
                onClick={handleSkip}
                className="absolute bottom-12 px-6 py-2 rounded-full border border-brand-primary/40 text-brand-text/80 text-sm hover:bg-brand-primary/10 transition-all active:scale-95 backdrop-blur-sm"
            >
                Skip Intro →
            </button>
        </div>
    );
};

export default Intro;
