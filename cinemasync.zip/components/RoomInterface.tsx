import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, RotateCw, Monitor, MessageCircle, Send, Users } from 'lucide-react';
import { Room, Message, User } from '../types';

interface RoomInterfaceProps {
    room: Room;
    currentUser: User;
    onLeave: () => void;
    onSendMessage: (text: string) => void;
    messages: Message[];
}

const RoomInterface: React.FC<RoomInterfaceProps> = ({ room, currentUser, onLeave, onSendMessage, messages }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [inputText, setInputText] = useState('');
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (inputText.trim()) {
            onSendMessage(inputText);
            setInputText('');
        }
    };

    return (
        <div className="glass-panel rounded-3xl p-4 md:p-6 mb-20 md:mb-0">
            {/* Room Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                        🎬 {room.name}
                    </h2>
                    <div className="flex items-center gap-2 mt-1">
                        <span className="bg-brand-primary/20 text-brand-primary px-2 py-0.5 rounded text-xs font-mono">
                            {room.id}
                        </span>
                        <span className="text-brand-muted text-xs flex items-center gap-1">
                            <Users size={12} /> {room.participants.length} watching
                        </span>
                    </div>
                </div>
                <div className="flex gap-2 w-full md:w-auto">
                     <button className="flex-1 md:flex-none px-4 py-2 bg-brand-primary/10 hover:bg-brand-primary/20 text-brand-text rounded-xl text-sm font-medium transition-colors border border-brand-primary/20">
                        Invite
                    </button>
                    <button 
                        onClick={onLeave}
                        className="flex-1 md:flex-none px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-200 rounded-xl text-sm font-medium transition-colors border border-red-500/20"
                    >
                        Leave
                    </button>
                </div>
            </div>

            {/* Video Placeholder */}
            <div className="aspect-video bg-gradient-to-br from-gray-900 to-black rounded-2xl border border-brand-primary/20 relative overflow-hidden group mb-6 shadow-2xl">
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
                    <div className="text-6xl mb-4 animate-float">
                        {room.currentMovie ? '🍿' : '🎬'}
                    </div>
                    <h3 className="text-xl md:text-2xl font-bold text-white mb-2">
                        {room.currentMovie ? room.currentMovie : 'Ready to Watch'}
                    </h3>
                    <p className="text-brand-muted max-w-md">
                        {room.currentMovie 
                            ? 'Synchronized viewing active. Enjoy the movie!' 
                            : 'Select a movie to start your synchronized viewing experience.'}
                    </p>
                </div>
                
                {/* Controls Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex items-center justify-center gap-4 md:gap-6">
                        <button className="p-2 text-white/80 hover:text-white transition-transform hover:scale-110">
                            <SkipBack size={24} />
                        </button>
                        <button 
                            onClick={() => setIsPlaying(!isPlaying)}
                            className="w-12 h-12 md:w-14 md:h-14 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-transform"
                        >
                            {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
                        </button>
                        <button className="p-2 text-white/80 hover:text-white transition-transform hover:scale-110">
                            <SkipForward size={24} />
                        </button>
                    </div>
                </div>
            </div>

            {/* Controls Bar */}
            <div className="flex justify-center gap-3 mb-6 overflow-x-auto pb-2 scrollbar-hide">
                <button className="px-4 py-2 bg-brand-primary/20 text-brand-primary rounded-xl flex items-center gap-2 text-sm font-medium border border-brand-primary/30 whitespace-nowrap">
                    <RotateCw size={16} className="animate-spin-slow" /> Sync Active
                </button>
                <button className="px-4 py-2 bg-brand-primary/10 text-brand-muted hover:text-brand-text rounded-xl flex items-center gap-2 text-sm font-medium border border-brand-primary/10 transition-colors whitespace-nowrap">
                    <Monitor size={16} /> Theater Mode
                </button>
            </div>

            {/* Chat Area */}
            <div className="bg-black/20 rounded-2xl border border-brand-primary/10 flex flex-col h-[300px]">
                <div className="p-3 border-b border-brand-primary/10 flex items-center gap-2 text-brand-muted text-sm">
                    <MessageCircle size={16} /> Chat Room
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {messages.length === 0 && (
                        <div className="text-center text-white/20 text-sm py-8 italic">
                            No messages yet. Start the conversation!
                        </div>
                    )}
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex flex-col ${msg.sender === currentUser.name ? 'items-end' : 'items-start'}`}>
                            <div className="flex items-baseline gap-2 mb-1">
                                <span className={`text-xs font-bold ${msg.isSystem ? 'text-brand-secondary' : 'text-brand-primary'}`}>
                                    {msg.sender}
                                </span>
                                <span className="text-[10px] text-white/30">{msg.timestamp}</span>
                            </div>
                            <div className={`
                                px-3 py-2 rounded-xl text-sm max-w-[85%]
                                ${msg.isSystem 
                                    ? 'bg-brand-secondary/10 text-brand-secondary border border-brand-secondary/20 w-full text-center' 
                                    : msg.sender === currentUser.name
                                        ? 'bg-brand-primary text-brand-darker font-medium rounded-tr-none'
                                        : 'bg-white/10 text-brand-text rounded-tl-none'
                                }
                            `}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    <div ref={chatEndRef} />
                </div>

                <form onSubmit={handleSend} className="p-3 border-t border-brand-primary/10 flex gap-2">
                    <input
                        type="text"
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Say something..."
                        className="flex-1 bg-white/5 border border-brand-primary/20 rounded-xl px-4 py-2 text-sm text-brand-text focus:outline-none focus:border-brand-primary/50 transition-colors placeholder:text-white/20"
                    />
                    <button 
                        type="submit"
                        disabled={!inputText.trim()}
                        className="p-2 bg-brand-primary text-brand-darker rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-secondary transition-colors"
                    >
                        <Send size={18} />
                    </button>
                </form>
            </div>
        </div>
    );
};

export default RoomInterface;
