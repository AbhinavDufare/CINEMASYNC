import React from 'react';
import { Toast, ToastType } from '../types';
import { CheckCircle, AlertCircle, Info, XCircle, X } from 'lucide-react';

interface ToastContainerProps {
    toasts: Toast[];
    onRemove: (id: string) => void;
}

const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onRemove }) => {
    const getIcon = (type: ToastType) => {
        switch (type) {
            case 'success': return <CheckCircle size={18} className="text-green-400" />;
            case 'error': return <XCircle size={18} className="text-red-400" />;
            case 'warning': return <AlertCircle size={18} className="text-yellow-400" />;
            default: return <Info size={18} className="text-blue-400" />;
        }
    };

    const getBorderColor = (type: ToastType) => {
         switch (type) {
            case 'success': return 'border-green-500/30 bg-green-950/80';
            case 'error': return 'border-red-500/30 bg-red-950/80';
            case 'warning': return 'border-yellow-500/30 bg-yellow-950/80';
            default: return 'border-blue-500/30 bg-blue-950/80';
        }
    };

    return (
        <div className="fixed top-4 right-4 z-[2000] flex flex-col gap-3 max-w-[90vw] md:max-w-sm w-full pointer-events-none">
            {toasts.map((toast) => (
                <div
                    key={toast.id}
                    className={`
                        pointer-events-auto flex items-center gap-3 p-4 rounded-xl shadow-2xl backdrop-blur-md border 
                        animate-[slideIn_0.4s_ease-out] transition-all transform hover:scale-105
                        ${getBorderColor(toast.type)}
                    `}
                    role="alert"
                >
                    <div className="flex-shrink-0">
                        {getIcon(toast.type)}
                    </div>
                    <p className="flex-1 text-sm font-medium text-white leading-relaxed">
                        {toast.message}
                    </p>
                    <button 
                        onClick={() => onRemove(toast.id)}
                        className="p-1 hover:bg-white/10 rounded-full transition-colors text-white/60 hover:text-white"
                    >
                        <X size={16} />
                    </button>
                </div>
            ))}
        </div>
    );
};

export default ToastContainer;
