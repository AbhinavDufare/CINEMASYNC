import React from 'react';
import { Home, Film, Search, Calendar, MonitorPlay } from 'lucide-react';
import { ViewState } from '../types';

interface NavigationProps {
    currentView: ViewState;
    onChange: (view: ViewState) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onChange }) => {
    const navItems = [
        { id: 'home', icon: Home, label: 'Home' },
        { id: 'room', icon: Film, label: 'Room' },
        { id: 'discover', icon: Search, label: 'Discover' },
        { id: 'schedule', icon: Calendar, label: 'Schedule' },
        { id: 'platforms', icon: MonitorPlay, label: 'Platforms' },
    ] as const;

    return (
        <>
            {/* Desktop Navigation (Top Tabs) */}
            <div className="hidden md:flex justify-center gap-4 mb-8 flex-wrap">
                {navItems.map((item) => (
                    <button
                        key={item.id}
                        onClick={() => onChange(item.id)}
                        className={`
                            px-6 py-3 rounded-full flex items-center gap-2 transition-all duration-300 border font-medium
                            ${currentView === item.id 
                                ? 'bg-gradient-to-r from-brand-primary to-brand-secondary text-brand-darker border-transparent shadow-[0_0_20px_rgba(255,138,101,0.4)] transform -translate-y-1' 
                                : 'bg-brand-primary/10 border-brand-primary/20 text-brand-text hover:bg-brand-primary/20 hover:-translate-y-0.5'
                            }
                        `}
                    >
                        <item.icon size={18} />
                        {item.label}
                    </button>
                ))}
            </div>

            {/* Mobile Navigation (Bottom Bar) */}
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-brand-darker/95 backdrop-blur-xl border-t border-brand-primary/20 pb-safe z-50">
                <div className="flex justify-around items-center p-2">
                    {navItems.map((item) => (
                        <button
                            key={item.id}
                            onClick={() => onChange(item.id)}
                            className={`
                                flex flex-col items-center p-2 rounded-xl transition-all duration-300 w-full
                                ${currentView === item.id 
                                    ? 'text-brand-primary' 
                                    : 'text-brand-muted hover:text-brand-text'
                                }
                            `}
                        >
                            <div className={`
                                p-1.5 rounded-full mb-1 transition-all duration-300
                                ${currentView === item.id ? 'bg-brand-primary/10 scale-110' : ''}
                            `}>
                                <item.icon size={22} />
                            </div>
                            <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
                        </button>
                    ))}
                </div>
            </div>
        </>
    );
};

export default Navigation;
