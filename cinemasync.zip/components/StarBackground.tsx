import React, { useEffect, useState } from 'react';

const StarBackground: React.FC = () => {
    const [stars, setStars] = useState<Array<{id: number, left: string, top: string, delay: string, duration: string}>>([]);

    useEffect(() => {
        const newStars = Array.from({ length: 50 }).map((_, i) => ({
            id: i,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            delay: `${Math.random() * 4}s`,
            duration: `${3 + Math.random() * 2}s`
        }));
        setStars(newStars);
    }, []);

    return (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(255,140,105,0.1)_0%,transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,182,135,0.08)_0%,transparent_50%)]" />
            
            {/* Stars */}
            {stars.map((star) => (
                <div
                    key={star.id}
                    className="absolute w-0.5 h-0.5 bg-[#ffd4a3] rounded-full animate-twinkle opacity-80"
                    style={{
                        left: star.left,
                        top: star.top,
                        animationDelay: star.delay,
                        animationDuration: star.duration
                    }}
                />
            ))}
        </div>
    );
};

export default StarBackground;
